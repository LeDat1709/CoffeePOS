﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using CoffeeSell.ObjClass;

namespace CoffeeSell.DataAccessLayer
{
    public class DAOUsedDiscount : DAO
    {
        // Create a new individual discount
        public bool CreateIndividualDiscount(UsedDiscount ind)
        {
            string cmString = @"
                INSERT INTO UsedDiscount (CustomerId, DiscountId)
                VALUES (@CustomerId, @DiscountId)";

            try
            {
                int rows = ExecuteNonQuery(
                    cmString,
                    new[] { "@CustomerId", "@DiscountId"},
                    new object[]
                    {
                        ind.GetCustomerId(),
                        ind.GetDiscountId(),
                    });

                return rows > 0;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"CreateIndividualDiscount error: {ex.Message}");
                return false;
            }
        }

        // Delete an individual discount
        public bool DeleteIndividualDiscount(int customerId, int discountId)
        {
            string cmString = @"
                DELETE FROM UsedDiscount
                WHERE CustomerId = @CustomerId AND DiscountId = @DiscountId";

            try
            {
                int rows = ExecuteNonQuery(
                    cmString,
                    new[] { "@CustomerId", "@DiscountId" },
                    new object[] { customerId, discountId });

                return rows > 0;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"DeleteIndividualDiscount error: {ex.Message}");
                return false;
            }
        }

        // Get all individual discounts
        public DataTable GetAllIndividualDiscounts()
        {
            try
            {
                return ExecuteQuery("SELECT * FROM UsedDiscount");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"GetAllIndividualDiscounts error: {ex.Message}");
                return new DataTable();
            }
        }

        // Get a specific individual discount by customerId and discountId
        public UsedDiscount GetIndividualDiscount(int customerId, int discountId)
        {
            string cmString = @"
                SELECT * FROM UsedDiscount
                WHERE CustomerId = @CustomerId AND DiscountId = @DiscountId";

            try
            {
                DataTable dt = ExecuteQuery(
                    cmString,
                    new[] { "@CustomerId", "@DiscountId" },
                    new object[] { customerId, discountId });

                if (dt.Rows.Count == 1)
                {
                    DataRow r = dt.Rows[0];
                    UsedDiscount ind = new UsedDiscount();
                    ind.SetCustomerId(Convert.ToInt32(r["CustomerId"]));
                    ind.SetDiscountId(Convert.ToInt32(r["DiscountId"]));
                    return ind;
                }

                return null;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"GetIndividualDiscount error: {ex.Message}");
                return null;
            }
        }
        
    }
}
