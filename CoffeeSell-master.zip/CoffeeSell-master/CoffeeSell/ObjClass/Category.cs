﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeSell.ObjClass
{
    public class Category
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }

        public Category(int categoryID, string categoryName)
        {
            CategoryID = categoryID;
            CategoryName = categoryName;
        }

        public Category()
        {
        }
        public int GetCategoryID()  => CategoryID;
        public string GetCategoryName() => CategoryName;
        public void SetCategoryID(int categoryID) => CategoryID = categoryID;
        public void SetCategoryName(string categoryName) => CategoryName = categoryName;
    }
}
