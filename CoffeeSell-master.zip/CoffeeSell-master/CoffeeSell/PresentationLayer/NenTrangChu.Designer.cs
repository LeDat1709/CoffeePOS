﻿namespace CoffeeSell
{
    partial class NenTrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NenTrangChu));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientPanel4 = new Guna.UI2.WinForms.Guna2GradientPanel();
            label2 = new Label();
            guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            label17 = new Label();
            label3 = new Label();
            guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            label16 = new Label();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            label1 = new Label();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            label14 = new Label();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            comboBox1 = new ComboBox();
            label4 = new Label();
            guna2GradientPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox4).BeginInit();
            guna2GradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox3).BeginInit();
            guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2GradientPanel4
            // 
            guna2GradientPanel4.BackColor = Color.FromArgb(0, 94, 165);
            guna2GradientPanel4.Controls.Add(label2);
            guna2GradientPanel4.Controls.Add(guna2PictureBox4);
            guna2GradientPanel4.Controls.Add(label17);
            guna2GradientPanel4.CustomizableEdges = customizableEdges3;
            guna2GradientPanel4.Location = new Point(112, 649);
            guna2GradientPanel4.Name = "guna2GradientPanel4";
            guna2GradientPanel4.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2GradientPanel4.Size = new Size(309, 192);
            guna2GradientPanel4.TabIndex = 16;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(121, 117);
            label2.Name = "label2";
            label2.Size = new Size(144, 31);
            label2.TabIndex = 3;
            label2.Text = "Khách hàng";
            label2.Click += label2_Click;
            // 
            // guna2PictureBox4
            // 
            guna2PictureBox4.CustomizableEdges = customizableEdges1;
            guna2PictureBox4.Image = (Image)resources.GetObject("guna2PictureBox4.Image");
            guna2PictureBox4.ImageRotate = 0F;
            guna2PictureBox4.Location = new Point(34, 93);
            guna2PictureBox4.Name = "guna2PictureBox4";
            guna2PictureBox4.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2PictureBox4.Size = new Size(70, 55);
            guna2PictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox4.TabIndex = 1;
            guna2PictureBox4.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.White;
            label17.Location = new Point(131, 29);
            label17.Name = "label17";
            label17.Size = new Size(109, 31);
            label17.TabIndex = 0;
            label17.Text = "Hóa đơn";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(121, 117);
            label3.Name = "label3";
            label3.Size = new Size(109, 31);
            label3.TabIndex = 2;
            label3.Text = "Hóa đơn";
            // 
            // guna2GradientPanel3
            // 
            guna2GradientPanel3.BackColor = Color.FromArgb(0, 94, 165);
            guna2GradientPanel3.Controls.Add(guna2PictureBox3);
            guna2GradientPanel3.Controls.Add(label3);
            guna2GradientPanel3.Controls.Add(label16);
            guna2GradientPanel3.CustomizableEdges = customizableEdges7;
            guna2GradientPanel3.Location = new Point(112, 402);
            guna2GradientPanel3.Name = "guna2GradientPanel3";
            guna2GradientPanel3.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2GradientPanel3.Size = new Size(309, 192);
            guna2GradientPanel3.TabIndex = 15;
            // 
            // guna2PictureBox3
            // 
            guna2PictureBox3.CustomizableEdges = customizableEdges5;
            guna2PictureBox3.Image = (Image)resources.GetObject("guna2PictureBox3.Image");
            guna2PictureBox3.ImageRotate = 0F;
            guna2PictureBox3.Location = new Point(34, 93);
            guna2PictureBox3.Name = "guna2PictureBox3";
            guna2PictureBox3.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2PictureBox3.Size = new Size(70, 55);
            guna2PictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox3.TabIndex = 1;
            guna2PictureBox3.TabStop = false;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.White;
            label16.Location = new Point(92, 29);
            label16.Name = "label16";
            label16.Size = new Size(126, 31);
            label16.TabIndex = 0;
            label16.Text = "Sản phẩm";
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.BackColor = Color.FromArgb(0, 94, 165);
            guna2GradientPanel1.Controls.Add(label1);
            guna2GradientPanel1.Controls.Add(guna2PictureBox1);
            guna2GradientPanel1.Controls.Add(label14);
            guna2GradientPanel1.CustomizableEdges = customizableEdges11;
            guna2GradientPanel1.Location = new Point(112, 156);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2GradientPanel1.Size = new Size(309, 192);
            guna2GradientPanel1.TabIndex = 13;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(121, 117);
            label1.Name = "label1";
            label1.Size = new Size(144, 31);
            label1.TabIndex = 2;
            label1.Text = "Khách hàng";
            label1.Click += label1_Click;
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.CustomizableEdges = customizableEdges9;
            guna2PictureBox1.Image = (Image)resources.GetObject("guna2PictureBox1.Image");
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(34, 93);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2PictureBox1.Size = new Size(70, 55);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox1.TabIndex = 1;
            guna2PictureBox1.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.White;
            label14.Location = new Point(67, 29);
            label14.Name = "label14";
            label14.Size = new Size(198, 31);
            label14.TabIndex = 0;
            label14.Text = "Tổng Doanh Thu";
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI Semibold", 25.8000011F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 163);
            guna2HtmlLabel6.ForeColor = Color.Black;
            guna2HtmlLabel6.Location = new Point(508, 45);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(684, 61);
            guna2HtmlLabel6.TabIndex = 17;
            guna2HtmlLabel6.Text = "PHẦN MỀM QUẢN LÝ BÁN CÀ PHÊ";
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(1351, 156);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(112, 28);
            comboBox1.TabIndex = 18;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(1253, 156);
            label4.Name = "label4";
            label4.Size = new Size(80, 31);
            label4.TabIndex = 3;
            label4.Text = "Năm: ";
            // 
            // NenTrangChu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1716, 964);
            Controls.Add(label4);
            Controls.Add(comboBox1);
            Controls.Add(guna2GradientPanel4);
            Controls.Add(guna2GradientPanel3);
            Controls.Add(guna2GradientPanel1);
            Controls.Add(guna2HtmlLabel6);
            Name = "NenTrangChu";
            Text = "NenTrangChu";
            Load += NenTrangChu_Load;
            guna2GradientPanel4.ResumeLayout(false);
            guna2GradientPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox4).EndInit();
            guna2GradientPanel3.ResumeLayout(false);
            guna2GradientPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox3).EndInit();
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Label label17;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Label label16;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Label label14;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox comboBox1;
        private Label label4;
    }
}