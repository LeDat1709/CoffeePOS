﻿namespace CoffeeSell
{
    partial class TrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangChu));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            panel11 = new Panel();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            label10 = new Label();
            panel8 = new Panel();
            guna2PictureBox14 = new Guna.UI2.WinForms.Guna2PictureBox();
            label8 = new Label();
            guna2PictureBox6 = new Guna.UI2.WinForms.Guna2PictureBox();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            panel9 = new Panel();
            guna2PictureBox16 = new Guna.UI2.WinForms.Guna2PictureBox();
            label9 = new Label();
            panel7 = new Panel();
            guna2PictureBox13 = new Guna.UI2.WinForms.Guna2PictureBox();
            label7 = new Label();
            panel6 = new Panel();
            guna2PictureBox12 = new Guna.UI2.WinForms.Guna2PictureBox();
            label6 = new Label();
            panel4 = new Panel();
            guna2PictureBox10 = new Guna.UI2.WinForms.Guna2PictureBox();
            label4 = new Label();
            panel3 = new Panel();
            guna2PictureBox9 = new Guna.UI2.WinForms.Guna2PictureBox();
            label3 = new Label();
            panel2 = new Panel();
            guna2PictureBox8 = new Guna.UI2.WinForms.Guna2PictureBox();
            label2 = new Label();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            panel1 = new Panel();
            guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            label1 = new Label();
            guna2CustomGradientPanel2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            lblDate = new Label();
            lblDays = new Label();
            lblTime = new Label();
            lblStaff = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblDisplayName = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            panel10 = new Panel();
            timer1 = new System.Windows.Forms.Timer(components);
            panel5 = new Panel();
            guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            label5 = new Label();
            guna2CustomGradientPanel1.SuspendLayout();
            panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox6).BeginInit();
            panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox16).BeginInit();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox13).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox12).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox10).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox9).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox8).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox7).BeginInit();
            guna2CustomGradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox2).BeginInit();
            SuspendLayout();
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.BackColor = SystemColors.ActiveCaptionText;
            guna2CustomGradientPanel1.Controls.Add(panel5);
            guna2CustomGradientPanel1.Controls.Add(panel11);
            guna2CustomGradientPanel1.Controls.Add(panel8);
            guna2CustomGradientPanel1.Controls.Add(guna2PictureBox6);
            guna2CustomGradientPanel1.Controls.Add(guna2HtmlLabel5);
            guna2CustomGradientPanel1.Controls.Add(panel9);
            guna2CustomGradientPanel1.Controls.Add(panel7);
            guna2CustomGradientPanel1.Controls.Add(panel6);
            guna2CustomGradientPanel1.Controls.Add(panel4);
            guna2CustomGradientPanel1.Controls.Add(panel3);
            guna2CustomGradientPanel1.Controls.Add(panel2);
            guna2CustomGradientPanel1.Controls.Add(guna2HtmlLabel1);
            guna2CustomGradientPanel1.Controls.Add(panel1);
            guna2CustomGradientPanel1.CustomizableEdges = customizableEdges23;
            guna2CustomGradientPanel1.FillColor = Color.FromArgb(0, 94, 165);
            guna2CustomGradientPanel1.FillColor2 = Color.FromArgb(0, 94, 165);
            guna2CustomGradientPanel1.FillColor3 = Color.FromArgb(0, 94, 165);
            guna2CustomGradientPanel1.FillColor4 = Color.FromArgb(0, 94, 165);
            guna2CustomGradientPanel1.Location = new Point(0, 3);
            guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges24;
            guna2CustomGradientPanel1.Size = new Size(277, 1007);
            guna2CustomGradientPanel1.TabIndex = 0;
            guna2CustomGradientPanel1.Paint += guna2CustomGradientPanel1_Paint;
            // 
            // panel11
            // 
            panel11.BackColor = Color.FromArgb(61, 132, 187);
            panel11.Controls.Add(guna2PictureBox1);
            panel11.Controls.Add(label10);
            panel11.Location = new Point(0, 379);
            panel11.Name = "panel11";
            panel11.Size = new Size(267, 60);
            panel11.TabIndex = 12;
            panel11.Paint += panel11_Paint;
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.BackColor = Color.Transparent;
            guna2PictureBox1.CustomizableEdges = customizableEdges3;
            guna2PictureBox1.Image = Properties.Resources.settings;
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(18, 8);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2PictureBox1.Size = new Size(40, 35);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox1.TabIndex = 14;
            guna2PictureBox1.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(64, 12);
            label10.Name = "label10";
            label10.Size = new Size(210, 31);
            label10.TabIndex = 2;
            label10.Text = "Lịch Sử Hệ Thống";
            label10.Click += label10_Click_1;
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(61, 132, 187);
            panel8.Controls.Add(guna2PictureBox14);
            panel8.Controls.Add(label8);
            panel8.Location = new Point(1, 313);
            panel8.Name = "panel8";
            panel8.Size = new Size(267, 60);
            panel8.TabIndex = 7;
            panel8.Paint += panel8_Paint;
            // 
            // guna2PictureBox14
            // 
            guna2PictureBox14.BackColor = Color.Transparent;
            guna2PictureBox14.CustomizableEdges = customizableEdges5;
            guna2PictureBox14.Image = (Image)resources.GetObject("guna2PictureBox14.Image");
            guna2PictureBox14.ImageRotate = 0F;
            guna2PictureBox14.Location = new Point(18, 8);
            guna2PictureBox14.Name = "guna2PictureBox14";
            guna2PictureBox14.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2PictureBox14.Size = new Size(40, 35);
            guna2PictureBox14.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox14.TabIndex = 18;
            guna2PictureBox14.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(64, 12);
            label8.Name = "label8";
            label8.Size = new Size(147, 31);
            label8.TabIndex = 2;
            label8.Text = "Khách Hàng";
            label8.Click += label8_Click;
            // 
            // guna2PictureBox6
            // 
            guna2PictureBox6.BackColor = Color.Transparent;
            guna2PictureBox6.CustomizableEdges = customizableEdges7;
            guna2PictureBox6.Image = (Image)resources.GetObject("guna2PictureBox6.Image");
            guna2PictureBox6.ImageRotate = 0F;
            guna2PictureBox6.Location = new Point(35, 920);
            guna2PictureBox6.Name = "guna2PictureBox6";
            guna2PictureBox6.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2PictureBox6.Size = new Size(40, 35);
            guna2PictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox6.TabIndex = 11;
            guna2PictureBox6.TabStop = false;
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Times New Roman", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            guna2HtmlLabel5.ForeColor = SystemColors.ButtonHighlight;
            guna2HtmlLabel5.Location = new Point(81, 933);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(147, 22);
            guna2HtmlLabel5.TabIndex = 10;
            guna2HtmlLabel5.Text = "Made by: The Boys";
            // 
            // panel9
            // 
            panel9.BackColor = Color.FromArgb(61, 132, 187);
            panel9.Controls.Add(guna2PictureBox16);
            panel9.Controls.Add(label9);
            panel9.Location = new Point(0, 643);
            panel9.Name = "panel9";
            panel9.Size = new Size(267, 60);
            panel9.TabIndex = 8;
            panel9.Paint += panel9_Paint;
            // 
            // guna2PictureBox16
            // 
            guna2PictureBox16.BackColor = Color.Transparent;
            guna2PictureBox16.CustomizableEdges = customizableEdges9;
            guna2PictureBox16.Image = (Image)resources.GetObject("guna2PictureBox16.Image");
            guna2PictureBox16.ImageRotate = 0F;
            guna2PictureBox16.Location = new Point(18, 12);
            guna2PictureBox16.Name = "guna2PictureBox16";
            guna2PictureBox16.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2PictureBox16.Size = new Size(40, 35);
            guna2PictureBox16.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox16.TabIndex = 20;
            guna2PictureBox16.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(64, 12);
            label9.Name = "label9";
            label9.Size = new Size(104, 31);
            label9.TabIndex = 2;
            label9.Text = "Báo Cáo";
            label9.Click += label9_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(61, 132, 187);
            panel7.Controls.Add(guna2PictureBox13);
            panel7.Controls.Add(label7);
            panel7.Location = new Point(0, 511);
            panel7.Name = "panel7";
            panel7.Size = new Size(267, 60);
            panel7.TabIndex = 3;
            panel7.Paint += panel7_Paint;
            // 
            // guna2PictureBox13
            // 
            guna2PictureBox13.BackColor = Color.Transparent;
            guna2PictureBox13.CustomizableEdges = customizableEdges11;
            guna2PictureBox13.Image = (Image)resources.GetObject("guna2PictureBox13.Image");
            guna2PictureBox13.ImageRotate = 0F;
            guna2PictureBox13.Location = new Point(18, 12);
            guna2PictureBox13.Name = "guna2PictureBox13";
            guna2PictureBox13.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2PictureBox13.Size = new Size(40, 35);
            guna2PictureBox13.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox13.TabIndex = 17;
            guna2PictureBox13.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(64, 12);
            label7.Name = "label7";
            label7.Size = new Size(129, 31);
            label7.TabIndex = 2;
            label7.Text = "Nhân Viên";
            label7.Click += label7_Click;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(61, 132, 187);
            panel6.Controls.Add(guna2PictureBox12);
            panel6.Controls.Add(label6);
            panel6.Location = new Point(0, 445);
            panel6.Name = "panel6";
            panel6.Size = new Size(267, 60);
            panel6.TabIndex = 3;
            panel6.Paint += panel6_Paint;
            // 
            // guna2PictureBox12
            // 
            guna2PictureBox12.BackColor = Color.Transparent;
            guna2PictureBox12.CustomizableEdges = customizableEdges13;
            guna2PictureBox12.Image = (Image)resources.GetObject("guna2PictureBox12.Image");
            guna2PictureBox12.ImageRotate = 0F;
            guna2PictureBox12.Location = new Point(18, 12);
            guna2PictureBox12.Name = "guna2PictureBox12";
            guna2PictureBox12.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2PictureBox12.Size = new Size(40, 35);
            guna2PictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox12.TabIndex = 16;
            guna2PictureBox12.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(64, 12);
            label6.Name = "label6";
            label6.Size = new Size(146, 31);
            label6.TabIndex = 2;
            label6.Text = "Khuyến Mãi";
            label6.Click += label6_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(61, 132, 187);
            panel4.Controls.Add(guna2PictureBox10);
            panel4.Controls.Add(label4);
            panel4.Location = new Point(0, 577);
            panel4.Name = "panel4";
            panel4.Size = new Size(267, 60);
            panel4.TabIndex = 6;
            panel4.Paint += panel4_Paint;
            // 
            // guna2PictureBox10
            // 
            guna2PictureBox10.BackColor = Color.Transparent;
            guna2PictureBox10.CustomizableEdges = customizableEdges15;
            guna2PictureBox10.Image = (Image)resources.GetObject("guna2PictureBox10.Image");
            guna2PictureBox10.ImageRotate = 0F;
            guna2PictureBox10.Location = new Point(18, 12);
            guna2PictureBox10.Name = "guna2PictureBox10";
            guna2PictureBox10.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2PictureBox10.Size = new Size(40, 35);
            guna2PictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox10.TabIndex = 15;
            guna2PictureBox10.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(64, 12);
            label4.Name = "label4";
            label4.Size = new Size(132, 31);
            label4.TabIndex = 2;
            label4.Text = "Sản Phẩm ";
            label4.Click += label4_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(61, 132, 187);
            panel3.Controls.Add(guna2PictureBox9);
            panel3.Controls.Add(label3);
            panel3.Location = new Point(0, 247);
            panel3.Name = "panel3";
            panel3.Size = new Size(267, 60);
            panel3.TabIndex = 5;
            panel3.Paint += panel3_Paint;
            // 
            // guna2PictureBox9
            // 
            guna2PictureBox9.BackColor = Color.Transparent;
            guna2PictureBox9.CustomizableEdges = customizableEdges17;
            guna2PictureBox9.Image = Properties.Resources.invoice;
            guna2PictureBox9.ImageRotate = 0F;
            guna2PictureBox9.Location = new Point(18, 8);
            guna2PictureBox9.Name = "guna2PictureBox9";
            guna2PictureBox9.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2PictureBox9.Size = new Size(40, 35);
            guna2PictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox9.TabIndex = 14;
            guna2PictureBox9.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(64, 12);
            label3.Name = "label3";
            label3.Size = new Size(112, 31);
            label3.TabIndex = 2;
            label3.Text = "Hóa Đơn";
            label3.Click += label3_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(61, 132, 187);
            panel2.Controls.Add(guna2PictureBox8);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(0, 181);
            panel2.Name = "panel2";
            panel2.Size = new Size(267, 60);
            panel2.TabIndex = 4;
            panel2.Paint += panel2_Paint;
            // 
            // guna2PictureBox8
            // 
            guna2PictureBox8.BackColor = Color.Transparent;
            guna2PictureBox8.CustomizableEdges = customizableEdges19;
            guna2PictureBox8.Image = Properties.Resources.grocery_store;
            guna2PictureBox8.ImageRotate = 0F;
            guna2PictureBox8.Location = new Point(18, 8);
            guna2PictureBox8.Name = "guna2PictureBox8";
            guna2PictureBox8.ShadowDecoration.CustomizableEdges = customizableEdges20;
            guna2PictureBox8.Size = new Size(40, 35);
            guna2PictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox8.TabIndex = 13;
            guna2PictureBox8.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(64, 12);
            label2.Name = "label2";
            label2.Size = new Size(121, 31);
            label2.TabIndex = 2;
            label2.Text = "Bán Hàng";
            label2.Click += label2_Click;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Showcard Gothic", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = SystemColors.HighlightText;
            guna2HtmlLabel1.Location = new Point(38, 29);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(181, 35);
            guna2HtmlLabel1.TabIndex = 3;
            guna2HtmlLabel1.Text = "Coffee Home";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(61, 132, 187);
            panel1.Controls.Add(guna2PictureBox7);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 115);
            panel1.Name = "panel1";
            panel1.Size = new Size(267, 60);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // guna2PictureBox7
            // 
            guna2PictureBox7.BackColor = Color.Transparent;
            guna2PictureBox7.CustomizableEdges = customizableEdges21;
            guna2PictureBox7.Image = Properties.Resources.home;
            guna2PictureBox7.ImageRotate = 0F;
            guna2PictureBox7.Location = new Point(18, 12);
            guna2PictureBox7.Name = "guna2PictureBox7";
            guna2PictureBox7.ShadowDecoration.CustomizableEdges = customizableEdges22;
            guna2PictureBox7.Size = new Size(40, 35);
            guna2PictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox7.TabIndex = 12;
            guna2PictureBox7.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(64, 12);
            label1.Name = "label1";
            label1.Size = new Size(128, 31);
            label1.TabIndex = 2;
            label1.Text = "Trang Chủ";
            label1.Click += label1_Click;
            // 
            // guna2CustomGradientPanel2
            // 
            guna2CustomGradientPanel2.Controls.Add(lblDate);
            guna2CustomGradientPanel2.Controls.Add(lblDays);
            guna2CustomGradientPanel2.Controls.Add(lblTime);
            guna2CustomGradientPanel2.Controls.Add(lblStaff);
            guna2CustomGradientPanel2.Controls.Add(lblDisplayName);
            guna2CustomGradientPanel2.Controls.Add(guna2Button2);
            guna2CustomGradientPanel2.Controls.Add(guna2Button1);
            guna2CustomGradientPanel2.Controls.Add(guna2CirclePictureBox1);
            guna2CustomGradientPanel2.Controls.Add(guna2HtmlLabel4);
            guna2CustomGradientPanel2.Controls.Add(guna2HtmlLabel3);
            guna2CustomGradientPanel2.Controls.Add(guna2HtmlLabel2);
            guna2CustomGradientPanel2.CustomizableEdges = customizableEdges30;
            guna2CustomGradientPanel2.FillColor = Color.FromArgb(0, 94, 165);
            guna2CustomGradientPanel2.FillColor2 = Color.FromArgb(0, 94, 165);
            guna2CustomGradientPanel2.FillColor3 = Color.FromArgb(0, 94, 165);
            guna2CustomGradientPanel2.FillColor4 = Color.FromArgb(0, 94, 165);
            guna2CustomGradientPanel2.Location = new Point(274, 3);
            guna2CustomGradientPanel2.Name = "guna2CustomGradientPanel2";
            guna2CustomGradientPanel2.ShadowDecoration.CustomizableEdges = customizableEdges31;
            guna2CustomGradientPanel2.Size = new Size(1649, 84);
            guna2CustomGradientPanel2.TabIndex = 1;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.BackColor = Color.Transparent;
            lblDate.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 163);
            lblDate.ForeColor = Color.White;
            lblDate.Location = new Point(787, 24);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(173, 28);
            lblDate.TabIndex = 12;
            lblDate.Text = "Ngày/Tháng/Năm";
            // 
            // lblDays
            // 
            lblDays.AutoSize = true;
            lblDays.BackColor = Color.Transparent;
            lblDays.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 163);
            lblDays.ForeColor = Color.White;
            lblDays.Location = new Point(581, 24);
            lblDays.Name = "lblDays";
            lblDays.Size = new Size(46, 28);
            lblDays.TabIndex = 11;
            lblDays.Text = "Thứ";
            // 
            // lblTime
            // 
            lblTime.AutoSize = true;
            lblTime.BackColor = Color.Transparent;
            lblTime.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 163);
            lblTime.ForeColor = Color.White;
            lblTime.Location = new Point(409, 24);
            lblTime.Name = "lblTime";
            lblTime.Size = new Size(42, 28);
            lblTime.TabIndex = 10;
            lblTime.Text = "Giờ";
            // 
            // lblStaff
            // 
            lblStaff.BackColor = Color.Transparent;
            lblStaff.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblStaff.ForeColor = Color.White;
            lblStaff.Location = new Point(171, 57);
            lblStaff.Name = "lblStaff";
            lblStaff.Size = new Size(32, 22);
            lblStaff.TabIndex = 9;
            lblStaff.Text = "Tên:";
            // 
            // lblDisplayName
            // 
            lblDisplayName.BackColor = Color.Transparent;
            lblDisplayName.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            lblDisplayName.ForeColor = Color.White;
            lblDisplayName.Location = new Point(165, 29);
            lblDisplayName.Name = "lblDisplayName";
            lblDisplayName.Size = new Size(32, 22);
            lblDisplayName.TabIndex = 8;
            lblDisplayName.Text = "Tên:";
            // 
            // guna2Button2
            // 
            guna2Button2.CustomizableEdges = customizableEdges25;
            guna2Button2.DisabledState.BorderColor = Color.DarkGray;
            guna2Button2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button2.FillColor = Color.FromArgb(247, 148, 29);
            guna2Button2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            guna2Button2.ForeColor = Color.White;
            guna2Button2.Location = new Point(1501, 0);
            guna2Button2.Name = "guna2Button2";
            guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges26;
            guna2Button2.Size = new Size(155, 84);
            guna2Button2.TabIndex = 4;
            guna2Button2.Text = "Đăng Xuất";
            guna2Button2.Click += guna2Button2_Click;
            // 
            // guna2Button1
            // 
            guna2Button1.CustomizableEdges = customizableEdges27;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.FromArgb(247, 148, 29);
            guna2Button1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(1319, 0);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges28;
            guna2Button1.Size = new Size(163, 84);
            guna2Button1.TabIndex = 3;
            guna2Button1.Text = "Đổi Mật Khẩu";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.BackColor = Color.Transparent;
            guna2CirclePictureBox1.Image = Properties.Resources.people;
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(30, 37);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges29;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(55, 39);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2CirclePictureBox1.TabIndex = 3;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            guna2HtmlLabel4.ForeColor = Color.White;
            guna2HtmlLabel4.Location = new Point(109, 57);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(62, 22);
            guna2HtmlLabel4.TabIndex = 2;
            guna2HtmlLabel4.Text = "Chức vụ: ";
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            guna2HtmlLabel3.ForeColor = Color.White;
            guna2HtmlLabel3.Location = new Point(109, 29);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(32, 22);
            guna2HtmlLabel3.TabIndex = 1;
            guna2HtmlLabel3.Text = "Tên:";
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            guna2HtmlLabel2.ForeColor = Color.White;
            guna2HtmlLabel2.Location = new Point(21, 9);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(153, 22);
            guna2HtmlLabel2.TabIndex = 0;
            guna2HtmlLabel2.Text = "Thông tin người dùng";
            // 
            // panel10
            // 
            panel10.Location = new Point(280, 93);
            panel10.Name = "panel10";
            panel10.Size = new Size(1632, 917);
            panel10.TabIndex = 2;
            // 
            // timer1
            // 
            timer1.Interval = 10000;
            timer1.Tick += timer1_Tick;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(61, 132, 187);
            panel5.Controls.Add(guna2PictureBox2);
            panel5.Controls.Add(label5);
            panel5.Location = new Point(1, 709);
            panel5.Name = "panel5";
            panel5.Size = new Size(267, 60);
            panel5.TabIndex = 13;
            panel5.Paint += panel5_Paint;
            // 
            // guna2PictureBox2
            // 
            guna2PictureBox2.BackColor = Color.Transparent;
            guna2PictureBox2.CustomizableEdges = customizableEdges1;
            guna2PictureBox2.Image = Properties.Resources.gear;
            guna2PictureBox2.ImageRotate = 0F;
            guna2PictureBox2.Location = new Point(18, 12);
            guna2PictureBox2.Name = "guna2PictureBox2";
            guna2PictureBox2.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2PictureBox2.Size = new Size(40, 35);
            guna2PictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox2.TabIndex = 20;
            guna2PictureBox2.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Emoji", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(64, 12);
            label5.Name = "label5";
            label5.Size = new Size(97, 31);
            label5.TabIndex = 2;
            label5.Text = "Cài Đặt";
            // 
            // TrangChu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1924, 1011);
            Controls.Add(panel10);
            Controls.Add(guna2CustomGradientPanel2);
            Controls.Add(guna2CustomGradientPanel1);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "TrangChu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TrangChu";
            WindowState = FormWindowState.Maximized;
            Load += TrangChu_Load;
            guna2CustomGradientPanel1.ResumeLayout(false);
            guna2CustomGradientPanel1.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox6).EndInit();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox16).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox13).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox12).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox10).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox9).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox8).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox7).EndInit();
            guna2CustomGradientPanel2.ResumeLayout(false);
            guna2CustomGradientPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Panel panel1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel2;
        private Panel panel7;
        private Label label7;
        private Panel panel6;
        private Label label6;
        private Panel panel4;
        private Label label4;
        private Panel panel3;
        private Label label3;
        private Panel panel2;
        private Label label2;
        private Panel panel9;
        private Label label9;
        private Panel panel8;
        private Label label8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox6;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox16;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox14;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox13;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox12;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox10;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox9;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox8;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Panel panel10;
        private Label lblDate;
        private Label lblDays;
        private Label lblTime;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblStaff;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblDisplayName;
        private System.Windows.Forms.Timer timer1;
        private Panel panel11;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Label label10;
        private Panel panel5;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Label label5;
    }
}