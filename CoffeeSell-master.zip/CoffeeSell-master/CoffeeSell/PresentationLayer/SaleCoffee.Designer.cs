﻿namespace CoffeeSell
{
    partial class SaleCoffee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SaleCoffee));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle16 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle17 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle18 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle13 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle14 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle15 = new DataGridViewCellStyle();
            panel1 = new Panel();
            panel2 = new Panel();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            label4 = new Label();
            guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            flowLayoutPanelCategories = new FlowLayoutPanel();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            button1 = new Button();
            flowLayoutPanelProducts = new FlowLayoutPanel();
            productUserControl1 = new ProductUserControl();
            productUserControl2 = new ProductUserControl();
            productUserControl3 = new ProductUserControl();
            productUserControl4 = new ProductUserControl();
            productUserControl5 = new ProductUserControl();
            label5 = new Label();
            guna2DataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            ID = new DataGridViewTextBoxColumn();
            Name = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            column = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            guna2PictureBox7 = new Guna.UI2.WinForms.Guna2PictureBox();
            panel8 = new Panel();
            comboBox4 = new ComboBox();
            pictureBox2 = new PictureBox();
            checkBox1 = new CheckBox();
            lblTien = new Label();
            lblTienGiam = new Label();
            button3 = new Button();
            label7 = new Label();
            label6 = new Label();
            txtKhachHang = new TextBox();
            txtSDT = new TextBox();
            labeltotal = new Label();
            button2 = new Button();
            label18 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            label19 = new Label();
            label20 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            guna2DataGridView2 = new Guna.UI2.WinForms.Guna2DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn7 = new DataGridViewTextBoxColumn();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            flowLayoutPanelCategories.SuspendLayout();
            flowLayoutPanelProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2DataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox7).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)guna2DataGridView2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(84, 125, 224);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1926, 35);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label3);
            panel2.Controls.Add(pictureBox1);
            panel2.Location = new Point(0, 32);
            panel2.Name = "panel2";
            panel2.Size = new Size(1926, 50);
            panel2.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label3.Location = new Point(755, 0);
            label3.Name = "label3";
            label3.Size = new Size(346, 41);
            label3.TabIndex = 3;
            label3.Text = "BÁN HÀNG - MANG VỀ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(68, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label4.Location = new Point(0, 85);
            label4.Name = "label4";
            label4.Size = new Size(0, 31);
            label4.TabIndex = 2;
            // 
            // guna2TextBox1
            // 
            guna2TextBox1.CustomizableEdges = customizableEdges13;
            guna2TextBox1.DefaultText = "";
            guna2TextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            guna2TextBox1.ForeColor = Color.FromArgb(64, 64, 64);
            guna2TextBox1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Location = new Point(223, 92);
            guna2TextBox1.Margin = new Padding(3, 4, 3, 4);
            guna2TextBox1.Name = "guna2TextBox1";
            guna2TextBox1.PlaceholderForeColor = Color.LightGray;
            guna2TextBox1.PlaceholderText = "Tìm kiếm theo tên sản phẩm";
            guna2TextBox1.SelectedText = "";
            guna2TextBox1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2TextBox1.Size = new Size(458, 60);
            guna2TextBox1.TabIndex = 5;
            guna2TextBox1.TextChanged += guna2TextBox1_TextChanged;
            // 
            // flowLayoutPanelCategories
            // 
            flowLayoutPanelCategories.AutoScroll = true;
            flowLayoutPanelCategories.Controls.Add(guna2Button1);
            flowLayoutPanelCategories.Location = new Point(0, 160);
            flowLayoutPanelCategories.Name = "flowLayoutPanelCategories";
            flowLayoutPanelCategories.Size = new Size(220, 894);
            flowLayoutPanelCategories.TabIndex = 6;
            // 
            // guna2Button1
            // 
            guna2Button1.CustomizableEdges = customizableEdges15;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(3, 3);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2Button1.Size = new Size(214, 78);
            guna2Button1.TabIndex = 0;
            guna2Button1.Text = "Tất Cả";
            guna2Button1.Click += guna2Button1_Click;
            // 
            // guna2BorderlessForm1
            // 
            guna2BorderlessForm1.ContainerControl = this;
            guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            button1.ForeColor = SystemColors.ButtonShadow;
            button1.Location = new Point(1177, 89);
            button1.Name = "button1";
            button1.Size = new Size(137, 65);
            button1.TabIndex = 7;
            button1.Text = "Tìm kiếm";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // flowLayoutPanelProducts
            // 
            flowLayoutPanelProducts.AutoScroll = true;
            flowLayoutPanelProducts.Controls.Add(productUserControl1);
            flowLayoutPanelProducts.Controls.Add(productUserControl2);
            flowLayoutPanelProducts.Controls.Add(productUserControl3);
            flowLayoutPanelProducts.Controls.Add(productUserControl4);
            flowLayoutPanelProducts.Controls.Add(productUserControl5);
            flowLayoutPanelProducts.Location = new Point(223, 160);
            flowLayoutPanelProducts.Name = "flowLayoutPanelProducts";
            flowLayoutPanelProducts.Size = new Size(1091, 894);
            flowLayoutPanelProducts.TabIndex = 8;
            flowLayoutPanelProducts.Paint += flowLayoutPanelProducts_Paint;
            // 
            // productUserControl1
            // 
            productUserControl1.Location = new Point(3, 3);
            productUserControl1.Name = "productUserControl1";
            productUserControl1.Size = new Size(270, 253);
            productUserControl1.TabIndex = 0;
            // 
            // productUserControl2
            // 
            productUserControl2.Location = new Point(279, 3);
            productUserControl2.Name = "productUserControl2";
            productUserControl2.Size = new Size(266, 253);
            productUserControl2.TabIndex = 1;
            // 
            // productUserControl3
            // 
            productUserControl3.Location = new Point(551, 3);
            productUserControl3.Name = "productUserControl3";
            productUserControl3.Size = new Size(263, 238);
            productUserControl3.TabIndex = 2;
            // 
            // productUserControl4
            // 
            productUserControl4.Location = new Point(820, 3);
            productUserControl4.Name = "productUserControl4";
            productUserControl4.Size = new Size(263, 238);
            productUserControl4.TabIndex = 3;
            // 
            // productUserControl5
            // 
            productUserControl5.Location = new Point(3, 262);
            productUserControl5.Name = "productUserControl5";
            productUserControl5.Size = new Size(270, 253);
            productUserControl5.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label5.Location = new Point(1534, 98);
            label5.Name = "label5";
            label5.Size = new Size(136, 38);
            label5.TabIndex = 4;
            label5.Text = "Giỏ hàng";
            // 
            // guna2DataGridView1
            // 
            dataGridViewCellStyle16.BackColor = Color.White;
            guna2DataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            dataGridViewCellStyle17.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle17.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle17.ForeColor = Color.White;
            dataGridViewCellStyle17.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = DataGridViewTriState.True;
            guna2DataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            guna2DataGridView1.ColumnHeadersHeight = 4;
            guna2DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            guna2DataGridView1.Columns.AddRange(new DataGridViewColumn[] { ID, Name, Column1, Column2, Column3, column, Column4 });
            dataGridViewCellStyle18.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = Color.White;
            dataGridViewCellStyle18.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle18.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle18.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle18.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle18.WrapMode = DataGridViewTriState.False;
            guna2DataGridView1.DefaultCellStyle = dataGridViewCellStyle18;
            guna2DataGridView1.GridColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.Location = new Point(1321, 160);
            guna2DataGridView1.Name = "guna2DataGridView1";
            guna2DataGridView1.RowHeadersVisible = false;
            guna2DataGridView1.RowHeadersWidth = 51;
            guna2DataGridView1.Size = new Size(568, 311);
            guna2DataGridView1.TabIndex = 9;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            guna2DataGridView1.ThemeStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            guna2DataGridView1.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            guna2DataGridView1.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            guna2DataGridView1.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            guna2DataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            guna2DataGridView1.ThemeStyle.HeaderStyle.Height = 4;
            guna2DataGridView1.ThemeStyle.ReadOnly = false;
            guna2DataGridView1.ThemeStyle.RowsStyle.BackColor = Color.White;
            guna2DataGridView1.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            guna2DataGridView1.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            guna2DataGridView1.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            guna2DataGridView1.ThemeStyle.RowsStyle.Height = 29;
            guna2DataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            guna2DataGridView1.CellContentClick += guna2DataGridView1_CellContentClick;
            // 
            // ID
            // 
            ID.HeaderText = "";
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            // 
            // Name
            // 
            Name.HeaderText = "Tên ";
            Name.MinimumWidth = 6;
            Name.Name = "Name";
            // 
            // Column1
            // 
            Column1.HeaderText = "Số lượng";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "Giá";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "Size";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            // 
            // column
            // 
            column.HeaderText = "Thành tiền";
            column.MinimumWidth = 6;
            column.Name = "column";
            // 
            // Column4
            // 
            Column4.HeaderText = "Hành động ";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            // 
            // guna2PictureBox7
            // 
            guna2PictureBox7.BackColor = Color.Transparent;
            guna2PictureBox7.CustomizableEdges = customizableEdges17;
            guna2PictureBox7.Image = (Image)resources.GetObject("guna2PictureBox7.Image");
            guna2PictureBox7.ImageRotate = 0F;
            guna2PictureBox7.Location = new Point(1787, 98);
            guna2PictureBox7.Name = "guna2PictureBox7";
            guna2PictureBox7.ShadowDecoration.CustomizableEdges = customizableEdges18;
            guna2PictureBox7.Size = new Size(40, 35);
            guna2PictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            guna2PictureBox7.TabIndex = 13;
            guna2PictureBox7.TabStop = false;
            guna2PictureBox7.Click += guna2PictureBox7_Click;
            // 
            // panel8
            // 
            panel8.Controls.Add(comboBox4);
            panel8.Controls.Add(pictureBox2);
            panel8.Controls.Add(checkBox1);
            panel8.Controls.Add(lblTien);
            panel8.Controls.Add(lblTienGiam);
            panel8.Controls.Add(button3);
            panel8.Controls.Add(label7);
            panel8.Controls.Add(label6);
            panel8.Controls.Add(txtKhachHang);
            panel8.Controls.Add(txtSDT);
            panel8.Controls.Add(labeltotal);
            panel8.Controls.Add(button2);
            panel8.Controls.Add(label18);
            panel8.Controls.Add(label13);
            panel8.Controls.Add(label12);
            panel8.Controls.Add(label11);
            panel8.Location = new Point(1320, 680);
            panel8.Name = "panel8";
            panel8.Size = new Size(569, 374);
            panel8.TabIndex = 14;
            panel8.Paint += panel8_Paint;
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(134, 144);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(135, 28);
            comboBox4.TabIndex = 20;
            comboBox4.SelectedIndexChanged += comboBox4_SelectedIndexChanged;
            // 
            // pictureBox2
            // 
           // pictureBox2.Image = Properties.Resources.bell;
            pictureBox2.Location = new Point(49, 144);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(60, 43);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click_1;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(433, 207);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(123, 24);
            checkBox1.TabIndex = 17;
            checkBox1.Text = "Chuyển khoản";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // lblTien
            // 
            lblTien.AutoSize = true;
            lblTien.Font = new Font("Segoe UI", 12F);
            lblTien.Location = new Point(420, 44);
            lblTien.Name = "lblTien";
            lblTien.Size = new Size(0, 28);
            lblTien.TabIndex = 16;
            // 
            // lblTienGiam
            // 
            lblTienGiam.AutoSize = true;
            lblTienGiam.Font = new Font("Segoe UI", 12F);
            lblTienGiam.Location = new Point(420, 88);
            lblTienGiam.Name = "lblTienGiam";
            lblTienGiam.Size = new Size(0, 28);
            lblTienGiam.TabIndex = 15;
            // 
            // button3
            // 
            button3.Location = new Point(247, 201);
            button3.Name = "button3";
            button3.Size = new Size(121, 34);
            button3.TabIndex = 14;
            button3.Text = "Khuyến mãi";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F);
            label7.Location = new Point(318, 148);
            label7.Name = "label7";
            label7.Size = new Size(82, 28);
            label7.TabIndex = 13;
            label7.Text = "Phải trả:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F);
            label6.Location = new Point(338, 92);
            label6.Name = "label6";
            label6.Size = new Size(62, 28);
            label6.TabIndex = 12;
            label6.Text = "Giảm:";
            // 
            // txtKhachHang
            // 
            txtKhachHang.Location = new Point(134, 92);
            txtKhachHang.Name = "txtKhachHang";
            txtKhachHang.Size = new Size(135, 27);
            txtKhachHang.TabIndex = 11;
            // 
            // txtSDT
            // 
            txtSDT.Location = new Point(134, 45);
            txtSDT.Name = "txtSDT";
            txtSDT.Size = new Size(135, 27);
            txtSDT.TabIndex = 10;
            txtSDT.TextChanged += txtSDT_TextChanged;
            // 
            // labeltotal
            // 
            labeltotal.AutoSize = true;
            labeltotal.Font = new Font("Segoe UI", 12F);
            labeltotal.ForeColor = Color.Red;
            labeltotal.Location = new Point(420, 144);
            labeltotal.Name = "labeltotal";
            labeltotal.Size = new Size(0, 28);
            labeltotal.TabIndex = 9;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(84, 125, 224);
            button2.Font = new Font("Segoe UI Semibold", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button2.ForeColor = Color.White;
            button2.Location = new Point(28, 255);
            button2.Name = "button2";
            button2.Size = new Size(523, 106);
            button2.TabIndex = 8;
            button2.Text = "Thanh toán";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(380, 177);
            label18.Name = "label18";
            label18.Size = new Size(0, 20);
            label18.TabIndex = 7;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 12F);
            label13.Location = new Point(301, 45);
            label13.Name = "label13";
            label13.Size = new Size(99, 28);
            label13.TabIndex = 2;
            label13.Text = "Tổng tiền:";
            label13.Click += label13_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F);
            label12.Location = new Point(10, 92);
            label12.Name = "label12";
            label12.Size = new Size(118, 28);
            label12.TabIndex = 1;
            label12.Text = "Khách hàng:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F);
            label11.Location = new Point(78, 41);
            label11.Name = "label11";
            label11.Size = new Size(50, 28);
            label11.TabIndex = 0;
            label11.Text = "SDT:";
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(1, 92);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(219, 28);
            comboBox1.TabIndex = 16;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // comboBox2
            // 
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(687, 95);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(219, 28);
            comboBox2.TabIndex = 17;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 12F);
            label19.Location = new Point(911, 91);
            label19.Name = "label19";
            label19.Size = new Size(123, 28);
            label19.TabIndex = 9;
            label19.Text = "Giá tối thiểu:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 12F);
            label20.Location = new Point(911, 125);
            label20.Name = "label20";
            label20.Size = new Size(101, 28);
            label20.TabIndex = 18;
            label20.Text = "Giá tối đa:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(1040, 92);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(131, 27);
            textBox1.TabIndex = 19;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(1040, 125);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(131, 27);
            textBox2.TabIndex = 20;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // guna2DataGridView2
            // 
            dataGridViewCellStyle13.BackColor = Color.White;
            guna2DataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            dataGridViewCellStyle14.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle14.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle14.ForeColor = Color.White;
            dataGridViewCellStyle14.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = DataGridViewTriState.True;
            guna2DataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            guna2DataGridView2.ColumnHeadersHeight = 4;
            guna2DataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            guna2DataGridView2.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7 });
            dataGridViewCellStyle15.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = Color.White;
            dataGridViewCellStyle15.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle15.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle15.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle15.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle15.WrapMode = DataGridViewTriState.False;
            guna2DataGridView2.DefaultCellStyle = dataGridViewCellStyle15;
            guna2DataGridView2.GridColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView2.Location = new Point(1320, 477);
            guna2DataGridView2.Name = "guna2DataGridView2";
            guna2DataGridView2.RowHeadersVisible = false;
            guna2DataGridView2.RowHeadersWidth = 51;
            guna2DataGridView2.Size = new Size(568, 197);
            guna2DataGridView2.TabIndex = 21;
            guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.Font = null;
            guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            guna2DataGridView2.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            guna2DataGridView2.ThemeStyle.BackColor = Color.White;
            guna2DataGridView2.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView2.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            guna2DataGridView2.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            guna2DataGridView2.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            guna2DataGridView2.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            guna2DataGridView2.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            guna2DataGridView2.ThemeStyle.HeaderStyle.Height = 4;
            guna2DataGridView2.ThemeStyle.ReadOnly = false;
            guna2DataGridView2.ThemeStyle.RowsStyle.BackColor = Color.White;
            guna2DataGridView2.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            guna2DataGridView2.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            guna2DataGridView2.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            guna2DataGridView2.ThemeStyle.RowsStyle.Height = 29;
            guna2DataGridView2.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            guna2DataGridView2.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            guna2DataGridView2.CellContentClick += guna2DataGridView2_CellContentClick;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.HeaderText = "";
            dataGridViewTextBoxColumn1.MinimumWidth = 6;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.HeaderText = "Tên ";
            dataGridViewTextBoxColumn2.MinimumWidth = 6;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.HeaderText = "Số lượng";
            dataGridViewTextBoxColumn3.MinimumWidth = 6;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.HeaderText = "Giá";
            dataGridViewTextBoxColumn4.MinimumWidth = 6;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.HeaderText = "Size";
            dataGridViewTextBoxColumn5.MinimumWidth = 6;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.HeaderText = "Thành tiền";
            dataGridViewTextBoxColumn6.MinimumWidth = 6;
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewTextBoxColumn7.HeaderText = "Hành động ";
            dataGridViewTextBoxColumn7.MinimumWidth = 6;
            dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // SaleCoffee
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1924, 1055);
            Controls.Add(guna2DataGridView2);
            Controls.Add(textBox1);
            Controls.Add(textBox2);
            Controls.Add(label20);
            Controls.Add(comboBox1);
            Controls.Add(label19);
            Controls.Add(comboBox2);
            Controls.Add(panel8);
            Controls.Add(guna2PictureBox7);
            Controls.Add(guna2DataGridView1);
            Controls.Add(label5);
            Controls.Add(flowLayoutPanelProducts);
            Controls.Add(button1);
            Controls.Add(flowLayoutPanelCategories);
            Controls.Add(guna2TextBox1);
            Controls.Add(label4);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            //Name = "SaleCoffee";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SaleCoffee";
            WindowState = FormWindowState.Maximized;
            Load += SaleCoffee_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            flowLayoutPanelCategories.ResumeLayout(false);
            flowLayoutPanelProducts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)guna2DataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox7).EndInit();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)guna2DataGridView2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Label label3;
        private FlowLayoutPanel flowLayoutPanelCategories;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Button button1;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView1;
        private Label label5;
        private FlowLayoutPanel flowLayoutPanelProducts;
        private Panel panel8;
        private Label label12;
        private Label label11;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox7;
        private Label label13;
        private Label label18;
        private Button button2;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label20;
        private Label label19;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private ProductUserControl productUserControl1;
        private ProductUserControl productUserControl2;
        private ProductUserControl productUserControl3;
        private ProductUserControl productUserControl4;
        private ProductUserControl productUserControl5;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn Name;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn column;
        private DataGridViewTextBoxColumn Column4;
        private Label labeltotal;
        private TextBox txtKhachHang;
        private TextBox txtSDT;
        private Label label6;
        private Label label7;
        private Button button3;
        private Label lblTien;
        private Label lblTienGiam;
        private CheckBox checkBox1;
        private PictureBox pictureBox2;
        private ComboBox comboBox4;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}